package chatting.application;

import java.net.*;
import java.io.*;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Server {
    
    private static List<DataOutputStream> clientStreams = new CopyOnWriteArrayList<>();
    
    public Server() {
        startServer(); 
    }
    
    
    private void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(6001)) {
            System.out.println("Sunucu baslatildi...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                DataOutputStream dout = new DataOutputStream(clientSocket.getOutputStream());
                clientStreams.add(dout);
                new Thread(new ClientHandler(clientSocket, dout)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    static class ClientHandler implements Runnable {
        private Socket clientSocket;
        private DataInputStream din;
        private DataOutputStream dout;

        public ClientHandler(Socket socket, DataOutputStream dout) throws IOException {
            this.clientSocket = socket;
            this.din = new DataInputStream(clientSocket.getInputStream());
            this.dout = dout;
        }
        public void run() {
            try {
                while (true) {
                    String message = din.readUTF();
                    broadcastMessage(message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    din.close();
                    clientSocket.close();
                    clientStreams.remove(dout);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        private void broadcastMessage(String message) {
            for (DataOutputStream clientDout : clientStreams) {
                try {
                    clientDout.writeUTF(message);
                    clientDout.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public static void main(String[] args) {
        new Server();
        
    }
}