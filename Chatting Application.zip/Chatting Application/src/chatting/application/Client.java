package chatting.application;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.util.Calendar;
import java.text.SimpleDateFormat;


public class Client implements ActionListener{
    
    private String username;
    private JLabel usernameLabel;
    
    JTextField text;
    static JPanel a1;
    static Box vertical = Box.createVerticalBox();
    static JFrame f = new JFrame();
    static DataOutputStream dout;
    static DataInputStream din;
    private static Map<String, String> registeredUsers = new HashMap<>();
    
   public Client() {
           
        createLoginUI(); 
   
    }
   
       private void createLoginUI() {
        JFrame loginFrame = new JFrame("Kayıt Ol / Giriş Yap");
        loginFrame.setSize(300, 150);
        loginFrame.setLayout(new FlowLayout());

        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JButton loginButton = new JButton("Giriş Yap");
        JButton registerButton = new JButton("Kayıt Ol");

    loginFrame.add(new JLabel("Kullanıcı Adı:"));
    loginFrame.add(usernameField);
    loginFrame.add(new JLabel("Şifre:"));
    loginFrame.add(passwordField);
    loginFrame.add(loginButton);
    loginFrame.add(registerButton);

    loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    loginFrame.setVisible(true);

    loginButton.addActionListener(e -> loginUser(usernameField.getText(), new String(passwordField.getPassword())));
    registerButton.addActionListener(e -> registerUser(usernameField.getText(), new String(passwordField.getPassword())));
    }
       
       
    private void updateUsernameDisplay(String username) {

     if (usernameLabel != null) {
        usernameLabel.setText(username);
        usernameLabel.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        usernameLabel.setForeground(Color.WHITE);
      }

}

private void registerUser(String username, String password) {
        if (isValidUsername(username) && isValidPassword(password)) {
            registeredUsers.put(username, password);
            
            JOptionPane.showMessageDialog(null, "Kayıt başarılı.");
            
             updateUsernameDisplay(username);
        } else {
            JOptionPane.showMessageDialog(null, "Geçersiz kullanıcı adı veya şifre.");
        }
   
    }


private void loginUser(String username, String password) {
    String registeredPassword = registeredUsers.get(username);
    if (registeredPassword != null && registeredPassword.equals(password)) {
        initializeUI();
        connectToServer();
        updateUsernameDisplay(username);
    } else {
        JOptionPane.showMessageDialog(null, "Kullanıcı adı veya şifre yanlış.");
    }
}


private boolean isValidUsername(String username) {
    return username != null && !username.trim().isEmpty();
}

private boolean isValidPassword(String password) {
  
    return password != null && password.length() >= 4; 
}



private void onLoginSuccess(String username) {
    this.username = username;
    initializeUI();
    connectToServer();
    updateUsernameDisplay(username);
}


  
    private void initializeUI(){
                
     f.setLayout(null);    
        
    JPanel p1 = new JPanel();
    p1.setLayout(null);
    p1.setBackground(new Color(7, 94, 84));
    p1.setBounds(0, 0, 450, 70);
    f.add(p1);
    
    a1 = new JPanel();
    a1.setLayout(new BoxLayout(a1, BoxLayout.Y_AXIS));
    JScrollPane scrollPane = new JScrollPane(a1);
    scrollPane.setBounds(5, 75, 440, 470); 
    f.add(scrollPane);
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/3.png"));
        Image i2=i1.getImage().getScaledInstance(25, 25, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel back=new JLabel(i3);
        back.setBounds(5,20,25,25);
        p1.add(back);

        back.addMouseListener(new MouseAdapter(){
            
        public void mouseClicked(MouseEvent ae){
             System.exit(0);
        }
    });
        
        ImageIcon i4=new ImageIcon(ClassLoader.getSystemResource("icons/2.png"));
        Image i5=i4.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
        ImageIcon i6=new ImageIcon(i5);
        JLabel profile=new JLabel(i6);
        profile.setBounds(40,10,50,50);
        p1.add(profile);
        
        
        ImageIcon i7=new ImageIcon(ClassLoader.getSystemResource("icons/video.png"));
        Image i8=i7.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
        ImageIcon i9=new ImageIcon(i8);
        JLabel video=new JLabel(i9);
        video.setBounds(300,20,30,30);
        p1.add(video);
        
        
        ImageIcon i10=new ImageIcon(ClassLoader.getSystemResource("icons/phone.png"));
        Image i11=i10.getImage().getScaledInstance(35, 30, Image.SCALE_DEFAULT);
        ImageIcon i12=new ImageIcon(i11);
        JLabel phone=new JLabel(i12);
        phone.setBounds(360,20,35,30);
        p1.add(phone);
        
        ImageIcon i13=new ImageIcon(ClassLoader.getSystemResource("icons/3icon.png"));
        Image i14=i13.getImage().getScaledInstance(10, 25, Image.SCALE_DEFAULT);
        ImageIcon i15=new ImageIcon(i14);
        JLabel morevert=new JLabel(i15);
        morevert.setBounds(420,20,10,25);
        p1.add(morevert);
        
        
        
    usernameLabel = new JLabel();
    usernameLabel.setFont(new Font("SAN_SERIF", Font.BOLD, 16));
    usernameLabel.setForeground(Color.WHITE);
    p1.add(usernameLabel);
    usernameLabel.setBounds(110, 15, 200, 20); 
    
    
    
        JLabel status=new JLabel("Şu an aktif");
        status.setBounds(110,35,100,18);
        status.setForeground(Color.WHITE);
        status.setFont(new Font("SAN_SERIF",Font.BOLD,10));
        p1.add(status);
        
        text=new JTextField();
        text.setBounds(20,565,250,30);
        text.setFont(new Font("SAN_SERIF",Font.PLAIN,16));
        f.add(text);
        
        JButton send= new JButton("Send");
        send.setBounds(275,555,120,30);
        send.setBackground(new Color(7,94,84));
        send.setForeground(Color.WHITE);
        send.addActionListener(this);
        send.setFont(new Font("SAN_SERIF",Font.PLAIN,16));
        f.add(send);
        
     
                
    f.setSize(450, 700);
    f.setLocationRelativeTo(null);
    f.setVisible(true);
    
    }
    
    
    
        private void connectToServer() {
        try {
            Socket socket = new Socket("127.0.0.1", 6001);
            din = new DataInputStream(socket.getInputStream());
            dout = new DataOutputStream(socket.getOutputStream());

            new Thread(this::listenForMessages).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    
    
    
public void actionPerformed(ActionEvent ae) {
    try {
        String out = text.getText();
        if (!out.isEmpty()) {
            String msgToSend = username + ":" + out;
            dout.writeUTF(msgToSend);
            text.setText("");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}


private void listenForMessages() {
    try {
        while (true) {
            String msg = din.readUTF();
            String sender = msg.split(":")[0];
            String actualMsg = msg.substring(sender.length()+1);
            SwingUtilities.invokeLater(() -> {
                if (sender.equals(this.username)) {
                    updateChatWindow(actualMsg, "RIGHT");
                } else {
                    updateChatWindow(actualMsg, "LEFT");
                }
            });
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}


private void updateChatWindow(String message, String alignment) {
    JPanel messagePanel = formatLabel(message);
    JPanel containerPanel = new JPanel(new BorderLayout());
    
    if ("RIGHT".equals(alignment)) {
        containerPanel.add(messagePanel, BorderLayout.LINE_END);
    } else if ("LEFT".equals(alignment)) {
        containerPanel.add(messagePanel, BorderLayout.LINE_START);
    }

    vertical.add(containerPanel);
    vertical.add(Box.createVerticalStrut(15));

    a1.add(vertical, BorderLayout.PAGE_START);

    
    f.validate();

    JScrollBar verticalScrollBar = ((JScrollPane) a1.getParent().getParent()).getVerticalScrollBar();
    verticalScrollBar.setValue(verticalScrollBar.getMaximum());
}

         
    
public static JPanel formatLabel(String message) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel messageLabel = new JLabel("<html><p style=\"width: 150px\">" + message + "</p></html>");
        messageLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        messageLabel.setBackground(new Color(37, 211, 102));
        messageLabel.setOpaque(true);
        messageLabel.setBorder(new EmptyBorder(15, 15, 15, 50));
        panel.add(messageLabel);

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        JLabel timeLabel = new JLabel(sdf.format(cal.getTime()));
        panel.add(timeLabel);

        return panel;
    }

   
    
    public static void main(String[] args) {
        new Client();

    }
}